<?php
require_once 'qa_connection.php';

$g_uid=$_GET['uid'];
$g_bid=$_GET['bid'];
$g_docid=$_GET['docid'];
echo "User:".$g_uid."   BranchID:".$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">Back to Main Menu</a></p></font></br>';
echo '<h1>Update, delete and add Counter</h1>';

$docid=array();
$column1=array();
$column2=array();
$column3=array();

$crec=0;
$g_check=0;
$db="tbl_counter";
$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$user_branchname=$doc->fname;
	$user_businessid=$doc->lname;

		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$user_branchname;
		$column3[$crec]=$user_businessid;
		
		$crec=$crec+1;
	
   }




echo '</br></br></br></br>';
echo '<form action="qa_admin_counter1.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'" method="post">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1"';


echo '<th><td>Docid</td><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	echo '<td>'.'<input type="text" disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col2_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col3_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';
echo '<td>';
echo '<table border="1"';
echo '<th><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>add</td></th>';
for ($x1 = 0; $x1 < 1; $x1++) {
    //echo "The number is: $x1 <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  disabled name="add1_'.$x1.'" id="add1_'.$x1.'" value="automatic" </td>';
	echo '<td>'.'<input type="text"  name="add2_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="text"  name="add3_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Add'.'" </td>';

	echo '</tr>';
}

echo '</table>';
echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php














?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>