<?php
require_once 'qa_connection.php';

if(isset($_POST['submit'])){
//echo "ÿes";

$bname=$_POST['txt_bname'];
$counter=$_POST['txt_counter'];
$maxserved=$_POST['txt_maxserved'];
$t_stime=$_POST['txt_stime'];
$t_etime=$_POST['txt_etime'];
$t_text=$_POST['txt_text'];
//date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
	$dt=date("Y/m/d h:i:s");
	//echo $dt."GG";
$sql = "INSERT INTO tbl_counter (branch_name,counter,num_staff,max_served,start_time,end_time,currenttime,ticketing_text,date_created) 
VALUES ('$bname', '$counter', 1,'$maxserved','$t_stime','$t_etime',0,'$t_text','$dt')";


//$conn->close();

}
?>

<html>
<script type="text/javascript">
function func_a()
{
	
	
	var bname=document.getElementById("txt_bname").value;
	var bcounter=document.getElementById("txt_counter").value;
	var bmax=document.getElementById("txt_maxserved").value;
	var bstime=document.getElementById("txt_stime").value;
	var betime=document.getElementById("txt_etime").value;
	var btext=document.getElementById("txt_text").value;
	alert (bcounter+"GG");
	var check=0;
	//alert("ee"+bname);
	//check branchname field
	if (bname=="") 
	{
			alert("Branch Name should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
	//check branchname field
	if (bcounter=="") 
	{
			alert("Counter Name should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
		//check branchname field
	if (bmax=="") 
	{
			alert("Msx Name should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
		//check branchname field
	if (bstime=="") 
	{
			alert("Starting time should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
		//check branchname field
	if (betime=="") 
	{
			alert("End time should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
			//check branchname field
	if (btext=="") 
	{
			alert("Text should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
	
	
	if (check==6)
	{	var res=document.getElementById("div_response");
		alert("ok");
		var res1="";
					var http = new XMLHttpRequest();
				var url = 'qa_form_admin1.php';
				//var params = 'orem=ipsum&name=binny';
				var params ="txt_bname="+bname+"&txt_counter="+bcounter+"&txt_maxserved="+bmax+"&txt_stime="+bstime+"&txt_etime="+betime+"&txt_text="+btext;
				http.open('POST', url, true);

				//Send the proper header information along with the request
				http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

				http.onreadystatechange = function() {//Call a function when the state changes.
					if(http.readyState == 4 && http.status == 200) {
						//alert(http.responseText);
						res.innerHTML=http.responseText;
						 res1=http.responseText;
						 bname.value="";
					}
				}
				http.send(params);
				alert("Wait for response");
				res.innerHTML=res1;
				
				
		
	}	

	
}	

</script>


<form method="POST">
<font size="20" color="blue"><center><a>New Record</a></center></font></br>
	<table>
		<tr>
				<td>BranchName</td>
				<td>
				
				<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">
				<?php
				
				$db="tbl_branch";
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				 foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					print_r ($doc);
					$user_bid=$doc->_id;
					$user_branchname=$doc->branchname;
					$user_businessid=$doc->businessid;
					echo "<br/>".$user_bid;
					echo "<br/>".$user_branchname;
					echo "<br/>".$user_businessid;
				
				
				echo '<option  value="'.$user_bid.'">'.$user_bid.'-'.$user_branchname.'</option>';
				 }
				//echo '</select>';
				?>
				</select>
				
				
				
				
				
				
				</td>
		
		</tr>
		
		<tr>
				<td>Counter</td>
				

				<td><select id="txt_counter" name="txt_counter">
				  <option value="1">1</option>
				  <option value="2">2</option>
				  <option value="3">3</option>
				  <option value="4">4</option>
				   <option value="5">5</option>
				    <option value="6">6</option>
					 <option value="7">7</option>
					  <option value="8">10</option>
					  <option value="9">11</option>
					  <option value="10">12</option>
				</select></td>
		
		</tr>
		
		<tr>
				<td>Max Served(In Minutes)</td>
				<td><select id="txt_maxserved" name="txt_maxserved">
				  <option value="5">5</option>
				  <option value="10">10</option>
				  <option value="15">15</option>
				  <option value="20">20</option>
				   <option value="30">30</option>
				    <option value="45">45</option>
					 <option value="60">60</option>
				</select></td>
		
		</tr>
	
	
		<tr>
				<td>Starting Time</td>
				<td><input type="datetime-local" id="txt_stime" name="txt_stime"/></td>
		
		</tr>
		<tr>
				<td>End Time</td>
				<td><input type="datetime-local" id="txt_etime" name="txt_etime"/></td>
		
		</tr>
		
		<tr>
				<td>Ticketing Text</td>
				<td><input type="text" id="txt_text" name="txt_text"/></td>
		
		</tr>
		
		
	
	
		<tr>
				<td><input type="button"  id="submit" name="submit" value="submit"  onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>


</html>