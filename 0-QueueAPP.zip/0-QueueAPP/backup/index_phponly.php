<?php
echo "ä test";

?>
