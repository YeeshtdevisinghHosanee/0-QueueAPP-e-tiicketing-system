<?php
require_once 'qa_connection.php';


if(isset($_POST['submit'])){

}
?>

<html>
<script type="text/javascript">
function func_a()
{
	
	
	var vuname=document.getElementById("txt_uname").value;
	var vpassword=document.getElementById("txt_password").value;
	var vfname=document.getElementById("txt_fname").value;
	var vlname=document.getElementById("txt_lname").value;
	
	//alert (vuname+"GG");
	var check=0;
	//alert("ee"+bname);
	//check branchname field
	if (vuname=="") 
	{
			alert("Username should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
	//check branchname field
	if (vpassword=="") 
	{
			alert("Password should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
		//check branchname field
	if (vfname=="") 
	{
			alert("First Name should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
		//check branchname field
	if (vlname=="") 
	{
			alert("Last Name should not be blank.");
	}	
	else
	{
		check=check+1;
		
	}	
	
	
	
	
	
	if (check==4)
	{	var res=document.getElementById("div_response");
		alert("Processing");
		var res1="";
					var http = new XMLHttpRequest();
				var url = 'qa_client_signup1.php';
				//var params = 'orem=ipsum&name=binny';
				var params ="username="+vuname+"&password="+vpassword+"&fname="+vfname+"&lname="+vlname;
				http.open('POST', url, true);

				//Send the proper header information along with the request
				http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

				http.onreadystatechange = function() {//Call a function when the state changes.
					if(http.readyState == 4 && http.status == 200) {
						//alert(http.responseText);
						res.innerHTML=http.responseText;
						 res1=http.responseText;
						 bname.value="";
					}
				}
				http.send(params);
				alert("Wait for response");
				res.innerHTML=res1;
				
				
		
	}	

	
}	

</script>


<form method="POST">
<font size="20" color="blue"><center><a>Sign up</a></center></font></br>
	<table>
		<tr>
				<td>Username</td>
				<td><input type="text" id="txt_uname" name="txt_uname"/></td>
		
		</tr>
		


	
		<tr>
				<td>Password</td>
				<td><input type="text" id="txt_password" name="txt_password"/></td>
		
		</tr>
		<tr>
				<td>FirstName</td>
				<td><input type="text" id="txt_fname" name="txt_fname"/></td>
		
		</tr>
		
		<tr>
				<td>LastName</td>
				<td><input type="text" id="txt_lname" name="txt_lname"/></td>
		
		</tr>
		
		
	
	
		<tr>
				<td><input type="button"  id="submit" name="submit" value="submit"  onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>


</html>