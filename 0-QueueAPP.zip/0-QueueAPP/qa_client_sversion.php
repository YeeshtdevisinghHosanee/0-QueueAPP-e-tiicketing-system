<?php

require_once 'qa_connection.php';

session_start() ;

	$clientid=$_SESSION['clientid'] ;
	$user=  $_SESSION['username'] ;
	$fname=  $_SESSION['fname'] ;
	 
	// echo $clientid."Hello ". $fname;
$chk1=0;
if ($clientid=="")
{
	if ($user=="")
	{
			$chk1=2;
	}	
}	

if ($chk1==0)
{	


$g_criteriaid="";
$g_counter="";
$g_val1="";
$g_val2="";
$g_val3="";
$g_val4="";
$g_val5="";
$g_val6="";
$g_val7="";

$doc=null;
$g_count1=0;
$g_count2=0;

////date_default_timezone_set('Asia/Dubai');
echo '<html><body style="background-color:#E6E6FA" >';
echo '<form action="qa_client_sversion1.php" method="post" >';
//echo '<font size="2" color="blue" ><p align="right"><a href="qa_login.php">Admin login</a></p></font></br>';

$db="tbl_counter_criteria";
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				echo '<select size="1" style="width:400px" height="20px" name="opt_criteriaid" id="opt_criteriaid">';
				foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					//print_r ($doc);
					$g_criteriaid=$doc->id;
					$g_counter=$doc->counter;
					$g_bid=$doc->branchid;
					$g_endingtime=$doc->end_time;
					$g_currenttim=$doc->current_time;
					$g_maxserved=$doc->maxserved;
					$g_startingtime=$doc->start_time;
					//echo "<br/>".$g_criteriaid;
					
					$g_endingtime1=date("d-M-yy", strtotime($g_endingtime));
					$db1="tbl_branch";
					$client1 = new couchClient($url,$db1);
					$all_records1 = $client1->getAllDocs();
					//$doc3 = $client1->asArray()->getDoc($g_bid);
					//echo "here1";
					//print_r($doc3);
					//echo "here2";
					foreach ( $all_records1->rows as $row1 ) 
					{
   
					$doc1 = CouchDocument::getInstance($client1,$row1->id);
					
					$user_bid=$doc1->_id;
					$user_branchname=$doc1->branchname;
					$user_businessid=$doc1->businessid;

					echo $g_endingtime1."branch<br/>".$user_bid;
					//echo "<br/>".$user_branchname;
					//echo "<br/>".$user_businessid;
					
				

					
					if ($user_bid==$g_bid)
					{
						
						
						
							$g_check=9;
							$g_val1=$user_bid;
							$g_val2=$user_branchname;
							$g_val3=$user_businessid;
								//echo '<option  value="'.$user_bid.'">'.$g_endingtime1.'_'.$g_val2.'-counter'.$g_counter.'</option>';
					
					
						//echo "here".$g_val2;
						
					}	
					
	
					}
					
				
						//echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.'</option>';
				 
				 
				 	$endingdate =date("Ymd", strtotime($g_endingtime));
					$todaydate=date("Ymd");
						//echo "</br>endingdate".$g_endingtime;
					//echo "</br>today".$todaydate;
					
					$endt =date("YmdHis", strtotime($g_endingtime));
					$todayt=date("YmdHis");
					
					
					$user_branchname=$g_val2;
					if ($endingdate==$todaydate)  // verify if selection is today's date
					{ 	$g_count1=2;
						if ($endt>$todayt)
						{
						
											$g_startingtime1=date("YmdHis", strtotime($g_startingtime));
											$todaydatetime=date("YmdHis");
											
											if ($todaydatetime>=$g_startingtime1)
											{
											
											$newtime_f =date("YmdHis", strtotime($g_currenttim)+($g_maxserved*60));
											$endtim_f =date("YmdHis", strtotime($g_endingtime));
											$status_availability="Avaliable";
											
											if ($newtime_f>$endtim_f) //new time should not be greater than ending time
											{
												$status_availability="Booked";
												
											
										
												//echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$user_branchname.' Counter'.$g_counter.' '.$status_availability.'"/>';
												echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.' fully booked</option>';

													
												
											}
											else
											{
										
										
												echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.'</option>';

											
												
											}	
																	
											}
											else{
											
												//echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$user_branchname.' Counter'.$g_counter.' '.'opens at '.date("H:i:s", strtotime($g_startingtime)).'"/>';
												echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.' opens at '.date("H:i:s", strtotime($g_startingtime)).'</option>';
											
															}
											
						}
						else{
							
								//echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$user_branchname.' Counter'.$g_counter.' '.'Already closed at '.date("H:i:s", strtotime($g_endingtime)).'"/>';
									echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.' already closed at '.date("H:i:s", strtotime($g_endingtime)).'</option>';
											
						}
						
						
					/**	
						echo '<td>';
					
					   echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']" value="'.$user_branchname.' Counter'.$g_counter.' '.$status_availability.'"/>';

						echo '</td>';**/
						$count_row=$count_row+1;
					}
					else
				    {
					
						$g_count2=2;
						//echo "no";
						
					}	
				}
			
				 	echo '</select>';
					
				
					echo '<input type="submit" name="submit" value="Get Ticket Number" />';
					echo '</form>';
	
					echo '</body ></html>';
					
					if ($g_count1==0 & $g_count2==0)
					{
						echo 'No counter available for today.';
					}
					
					
}
else{
	echo '<font size="3" color="black" ><p align="left">Click here to sign up/in to the system.<a href="index.html"> Homepage</a></font>';
}	
				 
				 //couchclient:https://github.com/dready92/PHP-on-Couch/blob/master/doc/couch_client-document.md
				//https://www.javadoc.io/static/com.cloudant/cloudant-sync-datastore-android/1.1.2/com/cloudant/mazha/CouchClient.html
?>
