<?php
require_once 'qa_connection.php';
$g_uid=$_GET['uid'];
$g_bid=$_GET['bid'];
$g_docid=$_GET['docid'];
echo '<font size="2" color="blue" ><p align="right"><a href="qa_super_login.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">Superuser Access</a>         <a href="qa_reset.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">Reset Password</a>   <a href="index.html">                 Log out</a></p></font></br>';

echo "Welcome user:".$g_uid;
echo "<br/>BranchID:".$g_bid;


$branchname="";
$ecounter="";

$g_val1="";
$g_val2="";
$g_val3="";
$g_val4="";
$g_val5="";
$g_val6="";
$g_val7="";

$g_check=0;
$db="tbl_branch";
$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$user_branchname=$doc->branchname;
	$user_businessid=$doc->businessid;

	//echo "<br/>".$user_bid;
	//echo "<br/>".$user_branchname;
	//echo "<br/>".$user_businessid;

	
	if ($user_bid==$g_bid)
	{
		
		
		
			$g_check=9;
			$g_val1=$user_bid;
			$g_val2=$user_branchname;
			$g_val3=$user_businessid;
		
		
	}	
	
	
   }




 
 if ($g_check==9)
 {
	// header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 echo "<br/>BranchName:".$g_val2;
	 echo "<br/>BusinessID:".$g_val3;
	 
 }

else
{
	
	echo "Username/Password not correct.";
}
echo  '</br>';
echo '<font size="10" color="blue">Manage:</br><a href="qa_admin_branch.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">1.Branch</a>     >>>>   <a href="qa_admin_counter.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">2.Counter</a>     >>>>   <a href="qa_admin_criteria.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">3.Counter Criteria</a></font>';
echo  '</br>';
echo  '</br>';

echo '</br><font size="10" color="blue">Monitor:</br><a href="qa_admin_montickets.php?uid='.$g_uid.'&bid='.$g_bid.'&docid='.$g_docid.'">1.Tickets</a></font>';


//echo '<font size="10" color="blue">Manage:</br><a href="'.header("Location: qa_admin_branch.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid).'"';

/**
echo '<font size="20" color="blue"><center><a href="qa_form_admin.php">Insert New</a></center></font></br>';

echo '<font size="20" color="blue"><center><a href="update_database.php">Update Existing</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href="delete_database.php">Deleting existing</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href=monitoring.php?bid='.$g_uid.'&ecounter='.$ecounter.'&bname='.$g_bid.'>Monitoring</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href="delete_file.php">Initialise Values</a></center></font></br>';
**/
?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>